import { Component, OnInit } from '@angular/core';
import { Agent } from '../model/agent';
import { Router } from '@angular/router';
import { RegisterService } from '../services/register.service';


@Component({
  selector: 'app-verifyreg',
  templateUrl: './verifyreg.component.html',
  styleUrls: ['./verifyreg.component.css']
})
export class VerifyregComponent implements OnInit {


  public agentObj: Agent;

  invalidRegister = false;
  registered = false;
  message = 'Registration success!';
  success = false;
  fail = false;
  constructor(private router: Router, private registerService: RegisterService) { }

  ngOnInit() {
    let agentString = sessionStorage.getItem('agent');
    console.log('agentString' + agentString);
    this.agentObj = JSON.parse(agentString);
    console.log("object values:" + this.agentObj.firstName);


  }

  back(){
    sessionStorage.removeItem('agent');
    this.router.navigate(['register'])

  }


  register() {
    let agentString = sessionStorage.getItem('agent');
    //sessionStorage.removeItem('agent');
    //console.log('in registration:'+agentString);


    this.registerService.regService(JSON.parse(agentString))
      .subscribe(
        data => {

          console.log('In success block:' + data)
          if (data === 'already registered') {
            //sessionStorage.removeItem('agent');
            this.invalidRegister = true;
            this.registered = true;
            message: "User Already Registered. Please proceed to ";



          } else if (data === 'registered') {
            this.success = true;
          } else {
            this.fail = true;
          }

        },
        error => {

          //this.invalidAgent=true;
          //this.errorMessage="Agent details not found! Please try again!"
          this.fail = true;

          console.log('error registration' + error.status + ':' + error.statusText + ':' + error.errorMessage);

        }
      )

  }


}
