import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../services/register.service';
import { Router } from '@angular/router';
import {FormControl} from '@angular/forms';
//import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
//import moment from 'moment';
import { Agent } from '../model/agent';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  licenseNo:string;
  panNo:string;
  dob:string;
 
 //dob=_moment( this.dob, '',true).format("YYYY-MM-DD HH:mm:ss").toString();
 
  invalidAgent=false;
  errorMessage:string;

 

  constructor(private router: Router,private registerService: RegisterService) { }

  ngOnInit() {
  }

  register(){
   
    console.log(this.licenseNo);
    console.log(this.panNo);
    console.log(this.dob);
   let licenseNo=this.licenseNo;
   let dob=this.dob;
   let panNo=this.panNo;

   this.resetForm();

    this.registerService.verifyRegisterService(licenseNo, panNo,dob)
      .subscribe(
        data => {
          console.log('In success block')
          let agent: Agent = data;
          if(agent.licenseNo!==null){
            sessionStorage.setItem('agent', JSON.stringify(agent));

            this.router.navigate(['verifyRegister'])
          }else if(data==='no data'){
            this.invalidAgent=true;
            this.errorMessage="Agent details not found! Please try again!"
          
            
          }

          
          //this.router.navigate(['register', this.username])
          //this.router.navigate(['verifyRegister'])
         
        },
        error => {

            this.invalidAgent=true;
            this.errorMessage="Agent details not found! Please try again!"
          
            
          
          console.log('error verifyregistration'+error.status+':'+error.statusText+':'+error.errorMessage);
         
        }
      )

  }


  resetForm(){
    this.licenseNo=null;
    this.panNo=null;
    this.dob=null;
  }

  }


