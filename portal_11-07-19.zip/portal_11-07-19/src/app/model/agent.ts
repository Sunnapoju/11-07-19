export interface Agent {
    
    licenseNo: string;
    panNo: string;
    dob: string;
    agentID: string;
    firstName: string;
   
    lastName: string;
    address: string;
    city: string;
    district: string;
    state: string;
    country: string;
    pincode: string;
    email: string;
    mobileNo: string;
    

	

}
