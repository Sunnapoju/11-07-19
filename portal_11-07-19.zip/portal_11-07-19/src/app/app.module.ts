import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppMaterialModule } from './core/material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ErrorComponent } from './error/error.component';


import { VerifyregComponent } from './verifyreg/verifyreg.component';
import { HeaderComponent } from './header/header.component';
//import { PCQComponent } from './product/pc/pc-q.component';
//import { PCComponent } from './product/pc/pc.component';
//import { StorageServiceModule} from 'angular-webstorage-service';

import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { ResetpwdComponent } from './resetpwd/resetpwd.component';
import { NgxSpinnerModule} from 'ngx-spinner'; 

import { CommonModule } from '@angular/common';
import { QuickQuoteComponent } from './products/PC/quick-quote/quick-quote.component';
import { AddInfoComponent } from './products/PC/add-info/add-info.component';
import { CommonTemplateComponent } from './products/common-template/common-template.component';
import { QuickQuoteMCIComponent } from './products/MCI/quick-quote-mci/quick-quote-mci.component';


import { CustomerInfoComponent } from './Customer/customer-info/customer-info.component';
import { NewCustomerDialogComponent } from './Customer/new-customer-dialog/new-customer-dialog.component';
import { ExistingCustomerDialogComponent } from './Customer/existing-customer-dialog/existing-customer-dialog.component';






@NgModule({
  
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ErrorComponent,
    VerifyregComponent,
    HeaderComponent,
    //PCQComponent,
    //PCComponent,

    ForgotpwdComponent,
    ResetpwdComponent,
    // CustomerComponent,
    // CustomerSearchDialog,


    QuickQuoteComponent,
    AddInfoComponent,
    CommonTemplateComponent,
    QuickQuoteMCIComponent,
    CustomerInfoComponent,

    NewCustomerDialogComponent,
    ExistingCustomerDialogComponent

  ],
  entryComponents: [NewCustomerDialogComponent, ExistingCustomerDialogComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    
    AppMaterialModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    CommonModule,
    FlexLayoutModule,
    NgxSpinnerModule

  ],
  exports: [AppMaterialModule],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
