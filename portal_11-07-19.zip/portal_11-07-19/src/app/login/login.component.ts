import { Component, OnInit } from '@angular/core';
import { AuthenticateService } from '../services/authenticate.service';
import { Router } from '@angular/router';
import {User} from '../model/user';
import * as _ from 'lodash';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //username = '9000008029';
  //password = 'NicAgent@123';

  username = '';
  password = '';
  errorMessage = 'Invalid Credentials';
  invalidLogin = false;
  mode = 'determinate';


  private _shown = false;

  constructor(private router: Router, private authenticateService: AuthenticateService) { }

  ngOnInit() {
  }

user:User;
activeUser:string;
  login() {
    console.log(this.username);
  


    this.authenticateService.login(this.username, this.password)
      .subscribe(
        data => {
          console.log(data.token)
         
         if(!_.isEmpty(data)){
            this.user.token=data.token;
            this.user.username=this.username;
            this.user.password=this.password;
            this.activeUser=JSON.stringify(this.user)
            sessionStorage.setItem("user", this.activeUser);
            this.authenticateService.currentUserSubject
          //this.router.navigate(['register', this.username])
          this.router.navigate(['products/quickquote']);
          this.invalidLogin = false
         }else{
           this.invalidLogin = true
         }
        },
        error => {
          console.log(error)
          this.invalidLogin = true

        }
      )
      if(this.invalidLogin){
         this.router.navigate(['login']);
      }
  }

  resetForm(){
    this.username=null;
    this.password=null;
  }

  

}
