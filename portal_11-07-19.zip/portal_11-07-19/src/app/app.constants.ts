//export const API_URL = "http://192.168.11.116:8001"
//export const API_URL = "http://192.168.11.116:7001/products/"

export const API_URL = "http://localhost:7001/"




