import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { API_URL } from './../app.constants';
import {User} from '../model/user';
import { BehaviorSubject, Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {


   public  currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;
    BASE_URL=API_URL;
    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }
//this.http.post<any>(`authenticate`, { username, password })
    login(username: string, password: string) {
        return this.http.post<User>(this.BASE_URL + `authenticate`, { username, password })    
    }     

    logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('user');
        this.currentUserSubject.next(null);
    }
}
