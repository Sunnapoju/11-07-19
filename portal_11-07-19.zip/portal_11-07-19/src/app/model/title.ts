export interface Title {
    id:number;
  value: string;
}
