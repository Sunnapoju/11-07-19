import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistingCustomerDialogComponent } from './existing-customer-dialog.component';

describe('ExistingCustomerDialogComponent', () => {
  let component: ExistingCustomerDialogComponent;
  let fixture: ComponentFixture<ExistingCustomerDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistingCustomerDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistingCustomerDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
