import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { API_URL } from './../app.constants';
import { map } from 'rxjs/operators';
import _moment from 'moment';
import { Agent } from '../model/agent';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    //'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient) { }
  api_url=API_URL;

 



  verifyRegisterService(licenseNo, panNo, dob) {

    dob=_moment(dob).format("DD-MM-YYYY");
    const url = `${this.api_url}registration/verifyRegister`;
    //const data = JSON.stringify(agent);
    return this.http.put<any>(url, {licenseNo,panNo,dob}).pipe(map(data=>{
      return data;
    })
  );


  
}


regService(agentString) {

  
  const url = `${this.api_url}registration/register`;
  //const data = JSON.stringify(agent);
  return this.http.put(url, agentString,{ responseType: 'text' }).pipe((data=>{
    return data;
  })
);

}






}





