import { Component, OnInit } from '@angular/core';
import { CommonServiceService } from '../../services/common-service.service';
@Component({
  selector: 'app-common-template',
  templateUrl: './common-template.component.html',
  styleUrls: ['./common-template.component.css']
})
export class CommonTemplateComponent implements OnInit {

//parentMessage: any = "From Parent...";
  constructor(private commonService:CommonServiceService) { }
  quote;
  permium;
  idv;
  tempresponse;
  ngOnInit() {
    this.commonService.common.subscribe(data => {
      this.tempresponse=data;
      this.quote=this.tempresponse.quoteNo;
      this.permium=this.tempresponse.permium;
      this.idv=this.tempresponse.idv;
    });
  }

}
