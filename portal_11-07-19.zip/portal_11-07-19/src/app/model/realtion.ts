export interface Realtion {
    id:string;
    value:string;
    
}
