import { Injectable } from '@angular/core';
import { API_URL } from '../app.constants';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { HttpHeaders, HttpClient } from '@angular/common/http';
import {Address} from '../model/address';
@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor( private httpClient: HttpClient) { }
  //http://192.168.11.116:7001/PortalDev/customer/getAddressFromPin
  //http://192.168.11.116:7001/PortalDev/customer/getAddressFromPin
private BASE_URL = API_URL;

 private serviceUrl=this.BASE_URL+"customer";
 private pincode="PINCODE_TABLE_QUERY:";
newCustomer;
existCustomer;
   getAddressDetailsByPincode(data): Observable < Address[] > {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'text/plain'
      })
    };
    data=this.pincode+data;
    console.log("Service:"+data);
    return this.httpClient.post < Address[] > (this.serviceUrl + '/getAddressFromPin', data, httpOptions);
    
  }

createCustomer(data){
     
 return this.httpClient.post(this.serviceUrl + '/createCustomer', JSON.stringify(data),  {headers: new HttpHeaders({'Content-Type': 'text/plain'}), responseType: 'text'});
        
}

searchCustomerbyId(data){
const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
 return this.httpClient.post(this.serviceUrl  + '/searchCustomer',data,
        httpOptions);
}


public tempRespObj;
tempComInfo={
  gmail:"",
  mobNo:0
}
gmail;
mobNo;
  getOccupationAndTitle(tableNames: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    console.log(tableNames);
     return this.httpClient.post(this.BASE_URL + 'quote/codeTables', tableNames);
  }//NIC_INDUSTRY_TYPE_QUERY
  
id;
setModalRef(id){
this.id=id;
}
getModalRef(){
  return this.id;
}

setCommInfo(commInfo){
this.tempComInfo.gmail=commInfo.gmail;
this.tempComInfo.mobNo=commInfo.mobno;
}
getCommInfo(){
  return this.tempComInfo;
}

}
