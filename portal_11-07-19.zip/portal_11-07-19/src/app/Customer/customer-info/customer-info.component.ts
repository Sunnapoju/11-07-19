import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NewCustomerDialogComponent } from '../new-customer-dialog/new-customer-dialog.component';
import { ExistingCustomerDialogComponent } from '../existing-customer-dialog/existing-customer-dialog.component';
import PCConstant from '../../data/pc-constant.json';
import { CustomerService } from '../../services/customer.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import CustConstant from '../../data/customer.json';
import moment from 'moment';
import { HttpClient } from '@angular/common/http';
import { API_URL } from '../../app.constants';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import * as _ from 'lodash';
import ADDConstant from '../../data/add-constant.json';

@Component({
  selector: 'app-customer-info',
  templateUrl: './customer-info.component.html',
  styleUrls: ['./customer-info.component.css']
})
export class CustomerInfoComponent implements OnInit {


  tempIP = API_URL;
  filterValue: any;

  //occupation dropdown
  occupationControl = new FormControl();
  occuFiltered: Observable<any[]>;
  occuObjArr: any;
 tempportalServiceInputObj = ADDConstant.portalServiceInputObj;



  buildOccupationDropdown(tempObjArr: any) {
    this.occuFiltered = this.occupationControl.valueChanges
      .pipe(startWith(''),
        map(tableObj => tableObj ? this._occupationFilter(tableObj) : tempObjArr.slice())
      );
  }

  private _occupationFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.occuObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }




  //occupation dropdown
  titleControl = new FormControl();
  titleFiltered: Observable<any[]>;
  titleObjArr: any;

  buildTitleDropdown(tempObjArr: any) {
    this.titleFiltered = this.titleControl.valueChanges
      .pipe(startWith(''),
        map(tableObj => tableObj ? this._titleFilter(tableObj) : tempObjArr.slice())
      );
  }

  private _titleFilter(tempObj: any): any[] {
    try {
      this.filterValue = tempObj.toLowerCase();
    } catch (e) {
      this.filterValue = tempObj.value.toLowerCase();
    }
    return this.titleObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
  }



  async onLoadGetCodeTables(tableNames: string) {
    await this.httpClient.post(this.tempIP + 'quote/codeTables', tableNames, { responseType: 'json' })
      .toPromise().then(
        data => {
          console.log('Response data ', data);
          const tempRespObjArr = data;
          const tempRespObj = tempRespObjArr[0];

          this.occuObjArr = tempRespObj.OCCUPATION_TABLE_QUERY;
          this.buildOccupationDropdown(this.occuObjArr);


        },
        error => {
          console.log('Error', error);
        }
      );
  }


  displayCommonFn(optionObj: any): any {
    return optionObj ? optionObj.value : optionObj;
  }


  
  customerType: string;
  buildingName: string;
  streetName: string;
  pincode: string;
  district: string;
  city: string;
  state: string;
  locality: string;
  country: string;


  emailId: string;
  mobile: string;
  phone: string;

  api_url = API_URL;

  tempCustIndObj = CustConstant.customerIndObject;
  tempCustCorpObj = CustConstant.customerCorpObject;

  new = false;
  existing = false;
  customerStatus = '';
  custName:string;
  custId:string;
  pan:string;


  responseJsonObj = { app: '', quoteNo: '', autoUwMsg: '' };

  ngOnInit() {
    //this.onLoadGetCodeTables('OCCUPATION_TABLE_QUERY:TITLE_TABLE_QUERY');
    //this.onLoadGetCodeTables('OCCUPATION_TABLE_QUERY');
  }

  constructor(public dialog: MatDialog, private httpClient: HttpClient,private customerService:CustomerService) { }

createCustJson;
dialogRef;
  openNewCustDialog(): void {
 
     this.dialogRef = this.dialog.open(NewCustomerDialogComponent, {
      position: {
        top: '12%',
        left: '35%'
      }

    });
    this.customerService.setModalRef(this.dialogRef);
    this.dialogRef.afterClosed().subscribe(result => {
       if(!_.isEmpty(result)){
    this.createCustJson=result;
    this.custName=this.createCustJson.custname;
    this.custId= this.createCustJson.custId;
    this.tempportalServiceInputObj.customerId=this.custId;
    this.tempportalServiceInputObj.customerName=this.custName.toUpperCase();
    this.tempportalServiceInputObj.customerType=this.createCustJson.customerType;
    ADDConstant.portalServiceInputObj=this.tempportalServiceInputObj;
       }
    });
  }
 custJson;
  openExistCustDialog(): void {
    const self=this;
    this.dialogRef = this.dialog.open(ExistingCustomerDialogComponent, {
      position: {
        top: '15%',
        left: '35%'
      }
    });
     this.customerService.setModalRef(this.dialogRef);
     console.log(this.custJson);
    this.dialogRef.afterClosed().subscribe(result => {
      if(!_.isEmpty(result)){
    this.custJson=result;
    this.custName=this.custJson.custName;
    this.custId= this.custJson.customerCode
    this.pan="SDFPL5678L";
    this.tempportalServiceInputObj.customerId=this.custId;
    this.tempportalServiceInputObj.customerName=this.custName.toUpperCase();
    this.tempportalServiceInputObj.customerType=this.custJson.customerType;
      ADDConstant.portalServiceInputObj=this.tempportalServiceInputObj;
      console.log(this.tempportalServiceInputObj);
      }
    });
   
 
  }
   view(){
     
   } 

}
